<?php
$languageStrings = array(
'Technische Zeichnungen (z.B. Isometrien Detailzeichnungen)'	=>	'Technische Zeichnungen (z.B. Isometrien Detailzeichnungen)',
'Zolltarifnummer'	=>	'Zolltarifnummer',
'Vorhandene europäische Zertifikate (z.B. ATEX CE ISO)'	=>	'Vorhandene europäische Zertifikate (z.B. ATEX CE ISO)',
'Technischer Pass (z.B. TR 004/020/2011) in Russisch'	=>	'Technischer Pass (z.B. TR 004/020/2011) in Russisch',
'Beschreibung des Produktes (in Russisch)'	=>	'Beschreibung des Produktes (in Russisch)',
'Technisches Datenblatt (in Russisch)'	=>	'Technisches Datenblatt (in Russisch)',
'Technischer Pass in Russisch'	=>	'Technischer Pass in Russisch',
);