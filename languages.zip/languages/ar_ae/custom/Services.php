<?php
$languageStrings = array(
'Document 1'	=>	'Document 1',
'Title'	=>	'Title',
);