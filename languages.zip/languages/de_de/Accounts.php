<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
$languageStrings = array(
	'Accounts'                     => 'Kunden'              , 
	'SINGLE_Accounts'              => 'Kunde'                , 
	'LBL_ADD_RECORD'               => 'Kunde Neu'            , 
	'LBL_RECORDS_LIST'             => 'Kunden Übersicht'              , 
	'LBL_ACCOUNT_INFORMATION'      => 'Kunden Informationen'                , 
	'LBL_SHOW_ACCOUNT_HIERARCHY'   => 'Zeige Organisationshierarchie', //Check
	'industry'                     => 'Gewerbe'                     , 
	'Account Name'                 => 'Firmenbezeichnung'                , 
	'Account No'                   => 'Kundennummer.'            , 
	'Website'                      => 'Webseite'                    , 
	'Ticker Symbol'                => 'Ticker Symbol'           , 
	'Member Of'                    => 'Kunde-Lieferant Beziehung'                , 
	'Employees'                    => 'Mitarbeiter'                 , 
	'Ownership'                    => 'Besitzer'                    , 
	'SIC Code'                     => 'USt. ID Nr.'                    , 
	'Other Email'                  => 'Zusätzliche E-Mail'               , 
	'Analyst'                      => 'Analyst'                     , 
	'Competitor'                   => 'Wettbewerber'                , 
	'Customer'                     => 'Kunde'                       , 
	'Integrator'                   => 'Integrator'                  , 
	'Investor'                     => 'Investor'                    , 
	'Press'                        => 'Presse'                      , 
	'Prospect'                     => 'Interessent'                 , 
	'Reseller'                     => 'Wiederverkäufer'            , 
	'LBL_START_DATE'               => 'Startdatum'                  , 
	'LBL_END_DATE'                 => 'Enddatum'                   , 
	'LBL_DUPLICATES_EXIST'         => 'ACHTUNG Doppelname', 
	'LBL_COPY_SHIPPING_ADDRESS'    => 'Versandadresse kopieren'       , 
	'LBL_COPY_BILLING_ADDRESS'     => 'Rechnungsadresse kopieren'        , 
    'LBL_IMAGE_INFORMATION' => 'Profil Bild',
    'Organization Image' => 'Firmen Logo',
    'Type'                         => 'Typ'                         , 

	'Other Phone' => 'Zusätzliche Telefon Nr.',
	'Phone' => 'Erst Telefon Nr.',
	'Email' => 'Erst E-Mail',

	'LBL_END_DATE'                 => 'Enddatum'                   , 
	'LBL_DUPLICATES_EXIST'         => 'Kunde existiert', 
	'LBL_COPY_SHIPPING_ADDRESS'    => 'Lieferadresse kopieren'       , 
	'LBL_COPY_BILLING_ADDRESS'     => 'Rechnungsadresse kopieren'        , 
);
$jsLanguageStrings = array(
	'LBL_RELATED_RECORD_DELETE_CONFIRMATION' => 'Kunde entfernen?', 
	'LBL_DELETE_CONFIRMATION'      => 'Durch das Entfernen des Kunden werden auch verknüpfte Verkaufschancen und Angebote entfernt. Jetzt dennoch entfernen?', 
	'LBL_MASS_DELETE_CONFIRMATION' => 'Durch das Entfernen des Kunden werden auch verknüpfte Verkaufschancen und Angebote entfernt. Jetzt dennoch entfernen?', 

	'JS_DUPLICATE_CREATION_CONFIRMATION' => 'Kunde bereits vorhanden ist.Doppelten Datensatz erstellen?',
);