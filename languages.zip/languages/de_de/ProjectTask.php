<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
$languageStrings = array(
	'SINGLE_ProjectTask'	=>	"Projektaufgabe",
	'LBL_ADD_RECORD'	=>	"Projektaufgabe hinzufügen",
	'LBL_RECORDS_LIST'	=>	"Verfügbare Projekte",
	'LBL_PROJECT_TASK_INFORMATION'	=>	"Projektaufgabe Details",
	'LBL_PROJECTS_LIST'	=>	"Projekte Liste",
	'LBL_TASKS_LIST'	=>	"Aufgabenliste",
	'LBL_MILESTONES_LIST'	=>	"Meilensteine ​​Liste",
	'Project Task Name'	=>	"Projekt Task-Name",
	'Project Task No'	=>	"Projektaufgabe Nummer",
	'Project Task Number'	=>	"Projektaufgabe Anzahl",
	'Status'	=>	"Status",
	'Priority'	=>	"Priorität",
	'Progress'	=>	"Fortschritt",
	'Type'	=>	"Typ",
	'Worked Hours'	=>	"Arbeitsstunden",
	'Start Date'	=>	"Startdatum",
	'End Date'	=>	"End Datum",
	'Related to'	=>	"Bezug zu",
	'administrative' => 'Administrativ',
    'operative' => 'Operativ',
    'other' => 'Andere',
    'low' => 'Niedrig',
    'normal' => 'Normal',
    'high' => 'Hoch',
	'Created Time'	=>	"Erstellt Zeit",
	'Modified Time'	=>	"Geändert Zeit",
	'description'	=>	"Beschreibung",
	'Assigned To'	=>	"Zuständig",
	'Open'	=>	"Öffnen",
	'In Progress'	=>	"in Bearbeitung",
	'Completed'	=>	"Fertiggestellt",
	'Deferred'	=>	"Zurückgestellt",
	'Canceled'	=>	"Gestrichen",
        'LBL_NO_DATE_VALUE_MSG' => 'oder Projektaufgaben nicht starten und / oder Enddatum',

  'Canceled ' => 'Abgebrochen',

);