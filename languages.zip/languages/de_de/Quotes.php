<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
$languageStrings = array(
    'Quotes'                       => 'Angebote'                     , 
	'SINGLE_Quotes'                => 'Angebot'                     , 
	'LBL_EXPORT_TO_PDF'            => 'Export als PDF'              , 
	'LBL_SEND_MAIL_PDF'            => 'Send Email with PDF'         , 
	'LBL_ADD_RECORD'               => 'Angebot erstellen'                   , 
	'LBL_RECORDS_LIST'             => 'Angebote Übersicht'                    , 
	'LBL_QUOTE_INFORMATION'        => 'Angebotsdetails'                     , 
	'Quote No'                     => 'Angebots Nr.'                 , 
	'Quote Stage'                  => 'Angebotsstatus'               , 
	'Valid Till'                   => 'Gültigkeitdauer'           , 
	'Inventory Manager'            => 'Bestandsmanager'             , 
	'Accepted'                     => 'akzeptiert'                  , 
	'Rejected'                     => 'abgelehnt'                   , 
	'Related To'                   => 'Bezogen auf'                 ,
	'ERTV'						   => 'DRTV'						,
	'Project Name'=>'Projektname',
	'Official in charge'=>'Sachbearbeiter',
	'Thanks for request'=>'Vielen Dank für Ihre Anfrage. Wir werden alles tun, um Ihre Anforderungen bestmöglich zu erfüllen',
	'Services'=>'Dienstleistungen',
	'Service'=>'Dienstleistung',
	'Products rules'=>'Entsprechend Ihrer Anfrage gelten folgende Regeln für Ihre Produkte',
	'Explanation'=>'Erläuterung',
	'Needed documents'=>'Für die Ausstellung dieser Erklärungen / Zertifikate benötigen wir die folgenden Dokumente',
	'Required documents'=>'Erforderliche Dokumente',
	'General Explanatory Notes'=>'Allgemeine Erläuterungen',
	'Shipping and payment'=>'Versand und Zahlung',
	'Further services'=>'Weitere Dienstleistungen',
	'Yours sincerely'=>'Dein',
	'Project manager'=>'Projektmanager',
	'This offer is valid until'=>'Dieses Angebot ist gültig bis',
	'and without signature'=>'und ohne Unterschrift',
	'For all subsequent orders the offer remains valid'=>'Für alle nachfolgenden Bestellungen bleibt das Angebot gültig',
	'Place and date'=>'Ort und Zeit',
	'Signature'=>'Unterschrift',
	'Company stamp'=>'Firmenstempel',


  'LBL_THIS' => 'Diese',
  'LBL_IS_DELETED_FROM_THE_SYSTEM_PLEASE_REMOVE_OR_REPLACE_THIS_ITEM' => 'wird aus dem system gelöscht.bitte entfernen oder ersetzen Sie diesen Artikel',
  'LBL_THIS_LINE_ITEM_IS_DELETED_FROM_THE_SYSTEM_PLEASE_REMOVE_THIS_LINE_ITEM' => 'Diese Position wird aus dem system gelöscht,bitte entfernen Sie diese Zeile Elemente',

);